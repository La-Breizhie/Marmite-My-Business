export function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-3xl bg-white p-5 shadow-sm border border-orange-100 ${className}`}>{children}</div>;
}

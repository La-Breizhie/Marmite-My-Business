'use client';
import { useState } from 'react';
import { Member } from '../lib/types';
export function MemberImport({ onImport }: { onImport: (rows: Partial<Member>[]) => void }) {
  const [message, setMessage] = useState('');
  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      const [headerLine, ...lines] = text.split(/\r?\n/).filter(Boolean);
      const headers = headerLine.split(',').map(h => h.trim());
      const rows = lines.map(line => {
        const values = line.split(',').map(v => v.trim());
        return headers.reduce((acc, key, i) => ({ ...acc, [key]: values[i] || '' }), {} as Partial<Member>);
      });
      onImport(rows);
      setMessage(`${rows.length} membre(s) importé(s) en prévisualisation.`);
    };
    reader.readAsText(file);
  }
  return <div className="rounded-2xl border border-dashed border-marmite-purple/40 p-4 bg-purple-50">
    <p className="font-bold mb-1">Importer les membres</p>
    <p className="text-sm text-gray-600 mb-3">CSV conseillé : firstName,lastName,email,phone,birthday,city,job,company,sponsorEmail</p>
    <input type="file" accept=".csv" onChange={handleFile} className="text-sm" />
    {message && <p className="text-sm mt-2 text-marmite-purple font-semibold">{message}</p>}
  </div>;
}

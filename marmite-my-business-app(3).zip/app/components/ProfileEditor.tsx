'use client';
import { useState } from 'react';
import { Member } from '../lib/types';
export function ProfileEditor({ member }: { member: Member }) {
  const [form, setForm] = useState(member);
  const [saved, setSaved] = useState(false);
  function update(key: keyof Member, value: string) { setForm(prev => ({ ...prev, [key]: value })); setSaved(false); }
  return <form className="grid gap-3" onSubmit={(e)=>{e.preventDefault(); setSaved(true);}}>
    <div className="grid md:grid-cols-2 gap-3">
      <input className="rounded-xl border p-3" value={form.firstName} onChange={e=>update('firstName', e.target.value)} placeholder="Prénom" />
      <input className="rounded-xl border p-3" value={form.lastName} onChange={e=>update('lastName', e.target.value)} placeholder="Nom" />
      <input className="rounded-xl border p-3" value={form.email} onChange={e=>update('email', e.target.value)} placeholder="Email" />
      <input className="rounded-xl border p-3" value={form.phone || ''} onChange={e=>update('phone', e.target.value)} placeholder="Téléphone" />
      <input className="rounded-xl border p-3" value={form.job} onChange={e=>update('job', e.target.value)} placeholder="Métier" />
      <input className="rounded-xl border p-3" value={form.company} onChange={e=>update('company', e.target.value)} placeholder="Entreprise" />
      <input className="rounded-xl border p-3" type="date" value={form.birthday || ''} onChange={e=>update('birthday', e.target.value)} />
      <select className="rounded-xl border p-3" value={form.city} onChange={e=>update('city', e.target.value as Member['city'])}>
        {['Combourg','Rennes','Saint-Malo','Brest','Global'].map(v => <option key={v}>{v}</option>)}
      </select>
    </div>
    <textarea className="rounded-xl border p-3 min-h-28" value={form.bio} onChange={e=>update('bio', e.target.value)} placeholder="Bio / présentation" />
    <button className="rounded-xl bg-marmite-purple text-white px-5 py-3 font-bold">Enregistrer ma fiche</button>
    {saved && <p className="text-green-700 font-semibold">Fiche enregistrée côté interface. À connecter ensuite à Supabase/DB.</p>}
  </form>;
}

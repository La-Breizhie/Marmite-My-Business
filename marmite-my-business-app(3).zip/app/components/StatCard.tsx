import { Card } from './Card';
export function StatCard({ label, value, note }: { label: string; value: string | number; note?: string }) {
  return <Card><p className="text-sm text-gray-500">{label}</p><p className="text-3xl font-black text-marmite-purple mt-1">{value}</p>{note && <p className="text-xs text-gray-400 mt-1">{note}</p>}</Card>;
}

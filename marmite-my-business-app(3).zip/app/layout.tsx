import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Marmite My Business App', description: 'Application communautaire Marmite My Business' };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="fr"><body>{children}</body></html>; }

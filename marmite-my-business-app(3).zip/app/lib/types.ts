export type Role = 'admin' | 'membre';
export type MarmiteVille = 'Global' | 'Combourg' | 'Rennes' | 'Saint-Malo' | 'Brest';
export type MemberStatus = 'invité' | 'actif' | 'à compléter';

export type Member = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  birthday?: string;
  city: MarmiteVille;
  job: string;
  company: string;
  bio: string;
  instagram?: string;
  linkedin?: string;
  sponsorId?: string;
  joinedAt: string;
  status: MemberStatus;
};

export type EventPresenceStatus = 'participation confirmée' | 'avec personne(s) invitée(s)' | 'absence confirmée' | 'en attente' | 'inscription sans présence';

export type EventAttendance = {
  eventId: string;
  memberId: string;
  status: EventPresenceStatus;
  checkedIn?: boolean;
  guestCount?: number;
  guestNames?: string;
};

export type Event = {
  id:string;
  title:string;
  date:string;
  city:MarmiteVille;
  type:'déjeuner'|'afterwork'|'atelier'|'autre';
  location:string;
  capacity?:number;
  status:'à venir'|'passé';
};

export type RecommendationStatus = 'nouvelle' | 'contact pris' | 'en cours' | 'gagnée' | 'perdue';
export type Recommendation = {
  id: string;
  fromMemberId: string;
  toMemberId: string;
  contactName: string;
  company?: string;
  need: string;
  value?: number;
  status: RecommendationStatus;
  createdAt: string;
};

export type Post = {
  id:string;
  authorId:string;
  city:MarmiteVille|'Toutes';
  content:string;
  createdAt:string;
  likes:number;
  comments:number;
  pinned?:boolean;
};

'use client';

import { useMemo, useState } from 'react';
import { CalendarDays, Cake, CheckCircle2, Handshake, Heart, Megaphone, Newspaper, Sparkles, Trophy, Upload, UserPlus, Users, Settings } from 'lucide-react';
import { attendances as initialAttendances, events, members as initialMembers, posts, recommendations as initialRecommendations } from './data/demo';
import { EventAttendance, EventPresenceStatus, Member, Recommendation } from './lib/types';
import { Card } from './components/Card';
import { StatCard } from './components/StatCard';
import { MemberImport } from './components/MemberImport';
import { ProfileEditor } from './components/ProfileEditor';

const presenceOptions: EventPresenceStatus[] = ['participation confirmée', 'avec personne(s) invitée(s)', 'absence confirmée', 'en attente', 'inscription sans présence'];
const statusColors: Record<string, string> = {
  'participation confirmée': 'bg-emerald-100 text-emerald-800',
  'avec personne(s) invitée(s)': 'bg-teal-100 text-teal-800',
  'absence confirmée': 'bg-rose-100 text-rose-800',
  'en attente': 'bg-amber-100 text-amber-800',
  'inscription sans présence': 'bg-slate-200 text-slate-800',
  gagnée: 'bg-emerald-100 text-emerald-800',
  'en cours': 'bg-violet-100 text-violet-800',
  nouvelle: 'bg-cyan-100 text-cyan-800',
  'contact pris': 'bg-amber-100 text-amber-800',
  perdue: 'bg-rose-100 text-rose-800'
};

export default function Home() {
  const [members, setMembers] = useState<Member[]>(initialMembers);
  const [attendance, setAttendance] = useState<EventAttendance[]>(initialAttendances);
  const [recommendations] = useState<Recommendation[]>(initialRecommendations);
  const [tab, setTab] = useState('dashboard');
  const currentMember = members[0];

  const upcoming = events.filter(e => e.status === 'à venir');
  const past = events.filter(e => e.status === 'passé');
  const sponsored = members.filter(m => m.sponsorId === currentMember.id).length;
  const presentPast = attendance.filter(a => past.some(e => e.id === a.eventId) && (a.status === 'participation confirmée' || a.status === 'avec personne(s) invitée(s)')).length;
  const expectedPast = Math.max(past.length * members.length, 1);
  const participationRate = Math.round((presentPast / expectedPast) * 100);
  const wonRecommendations = recommendations.filter(r => r.status === 'gagnée').length;
  const recommendationRate = Math.round((wonRecommendations / Math.max(recommendations.length, 1)) * 100);
  const currentMonth = new Date().getMonth() + 1;
  const birthdays = useMemo(() => [...members]
    .filter(m => m.birthday && Number((m.birthday || '').slice(5,7)) === currentMonth)
    .sort((a,b)=>(a.birthday || '').slice(8).localeCompare((b.birthday || '').slice(8))), [members, currentMonth]);
  const monthlyLunches = events.filter(e => e.type === 'déjeuner' && new Date(e.date).getMonth() + 1 === currentMonth).length;

  function importRows(rows: Partial<Member>[]) {
    const newMembers: Member[] = rows.map((row, index) => ({
      id: `import-${Date.now()}-${index}`,
      firstName: row.firstName || '', lastName: row.lastName || '', email: row.email || '', phone: row.phone || '', birthday: row.birthday || '',
      city: (row.city as Member['city']) || 'Global', job: row.job || 'À compléter', company: row.company || 'À compléter', bio: row.bio || '',
      joinedAt: new Date().toISOString().slice(0,10), status: 'invité'
    }));
    setMembers(prev => [...prev, ...newMembers]);
  }

  function setPresence(eventId: string, memberId: string, status: EventPresenceStatus) {
    setAttendance(prev => {
      const exists = prev.some(a => a.eventId === eventId && a.memberId === memberId);
      if (!exists) return [...prev, { eventId, memberId, status, guestCount: status === 'avec personne(s) invitée(s)' ? 1 : 0 }];
      return prev.map(a => a.eventId === eventId && a.memberId === memberId ? { ...a, status, guestCount: status === 'avec personne(s) invitée(s)' ? Math.max(a.guestCount || 1, 1) : 0 } : a);
    });
  }

  function presenceFor(eventId: string, memberId: string) {
    return attendance.find(a => a.eventId === eventId && a.memberId === memberId)?.status || 'en attente';
  }

  function eventStats(eventId: string) {
    const list = attendance.filter(a => a.eventId === eventId);
    const present = list.filter(a => a.status === 'participation confirmée' || a.status === 'avec personne(s) invitée(s)').length;
    const guests = list.reduce((sum, a) => sum + (a.guestCount || 0), 0);
    const noShow = list.filter(a => a.status === 'inscription sans présence').length;
    return { present, guests, noShow, total: list.length };
  }

  const nav = [
    ['dashboard','Dashboard',Trophy],['membres','Membres',Users],['import','Import & invitations',Upload],['events','Présences événements',CalendarDays],['reco','Recommandations',Handshake],['actus','Fil d’actualité',Newspaper],['profil','Ma fiche',Settings]
  ];

  return <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,#ffe4f4_0,#fff7ed_32%,#eef2ff_100%)]">
    <section className="relative overflow-hidden bg-gradient-to-br from-violet-700 via-fuchsia-600 to-orange-400 text-white px-6 py-9 rounded-b-[2.8rem] shadow-2xl">
      <div className="absolute right-10 top-8 h-32 w-32 rounded-full bg-white/15 blur-xl" />
      <div className="absolute left-1/2 bottom-0 h-24 w-80 rounded-full bg-yellow-200/20 blur-2xl" />
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end md:justify-between gap-6 relative">
        <div>
          <p className="uppercase tracking-[0.35em] text-xs opacity-80 flex items-center gap-2"><Sparkles size={16}/> Marmite My Business</p>
          <h1 className="text-4xl md:text-6xl font-black mt-2 leading-tight">Ta communauté, pilotée comme une vraie appli.</h1>
          <p className="mt-4 max-w-3xl opacity-95 text-lg">Membres, événements, présences, recommandations, personnes parrainées, anniversaires, fil d’actualité et fiches autonomes.</p>
        </div>
        <div className="bg-white/20 rounded-3xl p-5 backdrop-blur border border-white/25 min-w-[280px]">
          <p className="text-sm opacity-85">Mode test visuel</p>
          <p className="font-black text-2xl">MVP interactif ✨</p>
          <p className="text-sm mt-1 opacity-90">Prêt pour Supabase + invitations email</p>
        </div>
      </div>
    </section>

    <div className="max-w-7xl mx-auto p-6 grid lg:grid-cols-[270px_1fr] gap-6">
      <aside className="space-y-2 lg:sticky lg:top-6 h-fit">
        {nav.map(([id,label,Icon]: any) => <button key={id} onClick={()=>setTab(id)} className={`w-full flex items-center gap-3 rounded-2xl px-4 py-3 text-left font-bold transition shadow-sm ${tab===id?'bg-gradient-to-r from-violet-700 to-fuchsia-600 text-white scale-[1.02]':'bg-white/80 hover:bg-white'}`}><Icon size={18}/>{label}</button>)}
      </aside>

      <section className="space-y-6">
        {tab === 'dashboard' && <>
          <div className="grid md:grid-cols-6 gap-4">
            <StatCard label="Membres" value={members.length}/>
            <StatCard label="À venir" value={upcoming.length}/>
            <StatCard label="Participation" value={`${participationRate}%`}/>
            <StatCard label="Recommandations gagnées" value={`${recommendationRate}%`}/>
            <StatCard label="Mes parrainages" value={sponsored}/>
            <StatCard label="Repas ce mois" value={monthlyLunches}/>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <Card><h2 className="text-xl font-black mb-4 flex gap-2"><Cake className="text-fuchsia-600"/> Anniversaires du mois</h2>{birthdays.length === 0 && <p className="text-slate-500">Aucun anniversaire ce mois-ci.</p>}{birthdays.map(m => <p key={m.id} className="py-2 border-b last:border-0"><b>{m.firstName} {m.lastName}</b> — {m.birthday?.slice(5).split('-').reverse().join('/')}</p>)}</Card>
            <Card><h2 className="text-xl font-black mb-4 flex gap-2"><UserPlus className="text-violet-700"/> Top parrainage</h2>{members.map(m => ({m, count: members.filter(x=>x.sponsorId===m.id).length})).sort((a,b)=>b.count-a.count).slice(0,5).map(({m,count}) => <p key={m.id} className="py-2 border-b last:border-0"><b>{m.firstName}</b> — {count} personne(s) parrainée(s)</p>)}</Card>
          </div>
          <Card><h2 className="text-xl font-black mb-4 flex gap-2"><Handshake className="text-orange-500"/> Dernières recommandations business</h2><div className="grid md:grid-cols-2 gap-3">{recommendations.slice(0,4).map(r => <RecommendationCard key={r.id} r={r} members={members}/>)}</div></Card>
        </>}

        {tab === 'membres' && <Card><h2 className="text-2xl font-black mb-4">Annuaire des membres</h2><div className="grid md:grid-cols-2 gap-4">{members.map(m => <div key={m.id} className="rounded-3xl border border-violet-100 bg-white/70 p-4 shadow-sm"><p className="text-lg font-black">{m.firstName} {m.lastName}</p><p className="text-violet-700 font-semibold">{m.job}</p><p>{m.company} · {m.city}</p><p className="text-sm text-gray-500 mt-2">{m.bio || 'Fiche à compléter'}</p><div className="flex gap-2 mt-3 flex-wrap"><span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-bold">{m.status}</span><span className="rounded-full bg-violet-100 px-3 py-1 text-xs font-bold">{members.filter(x=>x.sponsorId===m.id).length} personne(s) parrainée(s)</span></div></div>)}</div></Card>}

        {tab === 'import' && <Card><h2 className="text-2xl font-black mb-4">Import des membres & invitations</h2><MemberImport onImport={importRows}/><div className="mt-5 rounded-3xl bg-gradient-to-r from-orange-100 to-fuchsia-100 p-5"><p className="font-black flex gap-2"><Megaphone/> Logique production :</p><p className="text-sm mt-1">Import CSV/base de données → statut “invité” → lien magique par email → la personne complète sa fiche → statut “actif” → elle peut gérer ses présences et recommandations.</p></div></Card>}

        {tab === 'events' && <div className="space-y-4">{events.map(e => { const stats = eventStats(e.id); const rate = Math.round((stats.present / Math.max(members.length, 1)) * 100); return <Card key={e.id}><div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3 mb-4"><div><h2 className="text-2xl font-black">{e.title}</h2><p className="text-gray-600">{e.date} · {e.city} · {e.location}</p></div><div className="flex gap-2 flex-wrap"><span className="rounded-full bg-emerald-100 text-emerald-800 px-3 py-1 text-sm font-black">{stats.present} participations confirmées</span><span className="rounded-full bg-teal-100 text-teal-800 px-3 py-1 text-sm font-black">+{stats.guests} personnes invitées</span><span className="rounded-full bg-slate-200 text-slate-800 px-3 py-1 text-sm font-black">{stats.noShow} no-show</span><span className="rounded-full bg-violet-100 text-violet-800 px-3 py-1 text-sm font-black">{rate}% participation</span></div></div><div className="grid md:grid-cols-2 gap-3">{members.map(m => <div key={m.id} className="rounded-2xl border bg-white/70 p-3 flex items-center justify-between gap-3"><div><p className="font-black">{m.firstName} {m.lastName}</p><p className="text-xs text-gray-500">{m.city} · {m.job}</p></div><select value={presenceFor(e.id,m.id)} onChange={ev=>setPresence(e.id,m.id,ev.target.value as EventPresenceStatus)} className={`rounded-xl px-3 py-2 text-sm font-bold ${statusColors[presenceFor(e.id,m.id)]}`} >{presenceOptions.map(opt => <option key={opt}>{opt}</option>)}</select></div>)}</div></Card>})}</div>}

        {tab === 'reco' && <Card><h2 className="text-2xl font-black mb-2">Recommandations & business apporté</h2><p className="text-gray-600 mb-5">Chaque opportunité est reliée à la personne qui recommande et à la personne qui reçoit le contact. Exemple : Arnaud → Marjorie pour Notion.</p><div className="grid md:grid-cols-2 gap-4">{recommendations.map(r => <RecommendationCard key={r.id} r={r} members={members}/>)}</div></Card>}

        {tab === 'actus' && <Card><h2 className="text-2xl font-black mb-4">Fil d’actualité</h2><textarea className="w-full rounded-3xl border border-fuchsia-100 p-4 mb-4 bg-white/80" placeholder="Écrire une annonce, une demande, une actu locale..."/><button className="rounded-2xl bg-gradient-to-r from-fuchsia-600 to-orange-400 text-white px-5 py-3 font-black mb-5 shadow-lg">Publier</button>{posts.map(p => { const author = members.find(m=>m.id===p.authorId); return <div key={p.id} className="rounded-3xl border border-violet-100 bg-white/75 p-4 mb-3"><p className="font-black">{author?.firstName} · {p.city}</p><p className="mt-2">{p.content}</p><p className="text-sm text-gray-500 mt-3">❤️ {p.likes} · 💬 {p.comments}</p></div>})}</Card>}

        {tab === 'profil' && <Card><h2 className="text-2xl font-black mb-4">Modifier ma fiche membre</h2><ProfileEditor member={currentMember}/><div className="mt-4 rounded-3xl bg-violet-50 p-4 text-sm"><b>À brancher :</b> en production, chaque membre modifiera uniquement sa fiche grâce à son compte ou son lien magique.</div></Card>}
      </section>
    </div>
  </main>;
}

function RecommendationCard({ r, members }: { r: Recommendation; members: Member[] }) {
  const from = members.find(m => m.id === r.fromMemberId);
  const to = members.find(m => m.id === r.toMemberId);
  return <div className="rounded-3xl border border-orange-100 bg-white/75 p-4 shadow-sm">
    <div className="flex justify-between gap-3 items-start">
      <p className="font-black text-lg">{r.contactName}</p>
      <span className={`rounded-full px-3 py-1 text-xs font-black ${statusColors[r.status] || 'bg-gray-100'}`}>{r.status}</span>
    </div>
    <p className="text-sm text-gray-600 mt-1">{r.company || 'Entreprise non renseignée'}</p>
    <p className="mt-3">{r.need}</p>
    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
      <p className="rounded-2xl bg-violet-50 p-3"><b>Recommandé par</b><br/>{from?.firstName}</p>
      <p className="rounded-2xl bg-fuchsia-50 p-3"><b>Pour</b><br/>{to?.firstName}</p>
    </div>
    {r.value ? <p className="mt-3 font-black text-emerald-700">Potentiel : {r.value} €</p> : null}
  </div>;
}

import { Event, EventAttendance, Member, Post, Recommendation } from '../lib/types';

export const members: Member[] = [
 {id:'m1',firstName:'Marjorie',lastName:'Falempin',email:'marjoflp@gmail.com',phone:'',birthday:'1986-03-19',city:'Combourg',job:'OBM / Notion / Automatisation',company:'La Breizhie',bio:'J’aide les entrepreneurs à remettre de l’ordre dans leur chaos digital.',instagram:'@marjoflp',linkedin:'',joinedAt:'2025-07-01',status:'actif'},
 {id:'m2',firstName:'Claire',lastName:'Martin',email:'claire@example.com',birthday:'1990-09-12',city:'Rennes',job:'Photographe',company:'Studio Claire',bio:'Portraits pro et images de marque.',sponsorId:'m1',joinedAt:'2025-08-12',status:'actif'},
 {id:'m3',firstName:'Nadia',lastName:'Le Gall',email:'nadia@example.com',birthday:'1988-11-02',city:'Saint-Malo',job:'Coach bien-être',company:'Nadia Wellness',bio:'Accompagnement énergie et équilibre.',sponsorId:'m1',joinedAt:'2025-09-03',status:'à compléter'},
 {id:'m4',firstName:'Paul',lastName:'Durand',email:'paul@example.com',birthday:'1982-06-21',city:'Brest',job:'Consultant RH',company:'Durand Conseil',bio:'Structuration RH pour PME.',sponsorId:'m2',joinedAt:'2025-10-10',status:'invité'},
 {id:'m5',firstName:'Arnaud',lastName:'Le Roux',email:'arnaud@example.com',birthday:'1979-01-14',city:'Combourg',job:'Architecte / Dirigeant',company:'Atelier ALR',bio:'Recherche des partenaires fiables pour structurer ses process.',sponsorId:'m1',joinedAt:'2026-01-08',status:'actif'}
];

export const events: Event[] = [
 {id:'e1',title:'Déjeuner Marmite Combourg',date:'2026-07-03',city:'Combourg',type:'déjeuner',location:'Combourg centre',capacity:20,status:'à venir'},
 {id:'e2',title:'Déjeuner Marmite Rennes',date:'2026-07-11',city:'Rennes',type:'déjeuner',location:'Rennes',capacity:30,status:'à venir'},
 {id:'e3',title:'Déjeuner Saint-Malo',date:'2026-05-18',city:'Saint-Malo',type:'déjeuner',location:'Intra-Muros',capacity:18,status:'passé'},
 {id:'e4',title:'Atelier recommandations',date:'2026-04-09',city:'Brest',type:'atelier',location:'Brest',capacity:15,status:'passé'}
];

export const attendances: EventAttendance[] = [
 {eventId:'e1', memberId:'m1', status:'présente'},
 {eventId:'e1', memberId:'m2', status:'présente avec invité(s)', guestCount:2, guestNames:'Lucie, Thomas'},
 {eventId:'e1', memberId:'m5', status:'présente avec invité(s)', guestCount:1, guestNames:'Sophie'},
 {eventId:'e2', memberId:'m2', status:'présente'},
 {eventId:'e2', memberId:'m3', status:'en attente'},
 {eventId:'e3', memberId:'m1', status:'présente', checkedIn:true},
 {eventId:'e3', memberId:'m3', status:'présente', checkedIn:true},
 {eventId:'e3', memberId:'m5', status:'inscrite mais non venue'},
 {eventId:'e4', memberId:'m1', status:'présente', checkedIn:true},
 {eventId:'e4', memberId:'m2', status:'présente', checkedIn:true},
 {eventId:'e4', memberId:'m3', status:'présente', checkedIn:true},
 {eventId:'e4', memberId:'m4', status:'absente'}
];

export const recommendations: Recommendation[] = [
 {id:'r1', fromMemberId:'m5', toMemberId:'m1', contactName:'Arnaud', company:'Atelier ALR', need:'Accompagnement Notion pour CRM candidatures + suivi commercial', value:1400, status:'en cours', createdAt:'2026-06-10'},
 {id:'r2', fromMemberId:'m1', toMemberId:'m2', contactName:'Séverine', company:'Institut bien-être', need:'Photos professionnelles pour nouvelle offre', value:450, status:'gagnée', createdAt:'2026-05-28'},
 {id:'r3', fromMemberId:'m2', toMemberId:'m3', contactName:'Pauline', company:'USANA', need:'Coaching énergie / équilibre', status:'contact pris', createdAt:'2026-06-02'},
 {id:'r4', fromMemberId:'m3', toMemberId:'m1', contactName:'Morgane', company:'Morgane Studio', need:'Audit organisationnel et automatisations', value:900, status:'nouvelle', createdAt:'2026-06-17'}
];

export const posts: Post[] = [
 {id:'p1',authorId:'m1',city:'Toutes',content:'Bienvenue dans la future application Marmite My Business 🔥 Pensez à compléter votre fiche membre.',createdAt:'2026-06-19',likes:12,comments:3,pinned:true},
 {id:'p2',authorId:'m2',city:'Rennes',content:'Qui sera présent au prochain afterwork de Rennes ?',createdAt:'2026-06-18',likes:5,comments:2}
];

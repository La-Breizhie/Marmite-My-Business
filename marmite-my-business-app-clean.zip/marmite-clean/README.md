# Marmite My Business — MVP test

Application Next.js propre, prête à déposer sur GitHub puis Vercel.

## Déploiement Vercel

1. Décompresse le ZIP.
2. Ouvre le dossier `marmite-clean`.
3. Envoie le CONTENU du dossier sur GitHub : `app`, `package.json`, `next.config.js`, `tsconfig.json`, `README.md`.
4. Dans Vercel : Add New Project > Import Git Repository.
5. Framework Preset : Next.js.
6. Root Directory : laisse vide si les fichiers sont à la racine du repo.
7. Build Command : `npm run build`.
8. Output Directory : ne rien mettre.

## Important

Ne mets pas le ZIP directement sur GitHub. Il faut mettre les fichiers décompressés.

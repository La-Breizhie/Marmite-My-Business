'use client';
import { useMemo, useState } from 'react';

type City = 'Combourg'|'Rennes'|'Saint-Malo'|'Brest'|'Global';
type Member = {id:string; firstName:string; lastName:string; email:string; phone?:string; birthday?:string; city:City; job:string; company:string; bio:string; sponsorId?:string; status:'invité'|'actif'|'à compléter'};
type EventStatus = 'participation confirmée'|'avec personne(s) invitée(s)'|'absence confirmée'|'en attente'|'inscription sans présence';
type Event = {id:string; title:string; date:string; city:City; location:string; type:'déjeuner'|'afterwork'|'atelier'; status:'à venir'|'passé'};
type Attendance = {eventId:string; memberId:string; status:EventStatus; guestCount?:number};
type Recommendation = {id:string; fromMemberId:string; toMemberId:string; contactName:string; company?:string; need:string; value?:number; status:'nouvelle'|'contact pris'|'en cours'|'gagnée'|'perdue'};

const initialMembers: Member[] = [
  {id:'m1',firstName:'Marjorie',lastName:'Falempin',email:'marjorie@email.fr',phone:'',birthday:'1986-03-19',city:'Combourg',job:'Bras droit digital / Notion',company:'La Breizhie',bio:'Structure, simplifie et optimise les process.',status:'actif'},
  {id:'m2',firstName:'Arnaud',lastName:'Guidot',email:'arnaud@email.fr',birthday:'1982-06-14',city:'Rennes',job:'Architecte',company:'Atelier Guidot',bio:'Projet CRM et suivi candidatures.',sponsorId:'m1',status:'actif'},
  {id:'m3',firstName:'Sophie',lastName:'Martin',email:'sophie@email.fr',birthday:'1990-06-22',city:'Saint-Malo',job:'Coach bien-être',company:'Sophie Wellness',bio:'Accompagnement équilibre et énergie.',sponsorId:'m1',status:'actif'},
  {id:'m4',firstName:'Thomas',lastName:'Leroy',email:'thomas@email.fr',birthday:'1988-09-03',city:'Brest',job:'Photographe',company:'Studio TL',bio:'Portraits pros et contenus visuels.',sponsorId:'m2',status:'à compléter'}
];
const events: Event[] = [
  {id:'e1',title:'Déjeuner Marmite Combourg',date:'2026-06-12',city:'Combourg',location:'Combourg centre',type:'déjeuner',status:'passé'},
  {id:'e2',title:'Déjeuner Marmite Rennes',date:'2026-06-20',city:'Rennes',location:'Rennes',type:'déjeuner',status:'à venir'},
  {id:'e3',title:'Atelier recommandations',date:'2026-05-18',city:'Global',location:'Visio',type:'atelier',status:'passé'}
];
const initialAttendance: Attendance[] = [
  {eventId:'e1',memberId:'m1',status:'participation confirmée'}, {eventId:'e1',memberId:'m2',status:'avec personne(s) invitée(s)',guestCount:2}, {eventId:'e1',memberId:'m3',status:'inscription sans présence'},
  {eventId:'e2',memberId:'m1',status:'en attente'}, {eventId:'e2',memberId:'m2',status:'avec personne(s) invitée(s)',guestCount:1},
  {eventId:'e3',memberId:'m1',status:'participation confirmée'}, {eventId:'e3',memberId:'m4',status:'absence confirmée'}
];
const recommendations: Recommendation[] = [
  {id:'r1',fromMemberId:'m2',toMemberId:'m1',contactName:'Arnaud Guidot',company:'Atelier Guidot',need:'Accompagnement Notion pour CRM candidatures et prospects',value:1400,status:'en cours'},
  {id:'r2',fromMemberId:'m1',toMemberId:'m3',contactName:'Claire Dubois',company:'Maison Claire',need:'Besoin coaching bien-être',value:600,status:'gagnée'},
  {id:'r3',fromMemberId:'m3',toMemberId:'m4',contactName:'Julien Moreau',company:'JM Conseil',need:'Photos professionnelles LinkedIn',status:'contact pris'}
];
const posts = [{id:'p1',author:'Marjorie',city:'Global',content:'Bienvenue sur l’espace test Marmite My Business ✨'}, {id:'p2',author:'Arnaud',city:'Rennes',content:'Je cherche un prestataire pour structurer un CRM Notion.'}];
const statusClass: Record<EventStatus|string,string> = {'participation confirmée':'green','avec personne(s) invitée(s)':'teal','absence confirmée':'rose','en attente':'amber','inscription sans présence':'slate','gagnée':'green','en cours':'violet','contact pris':'amber','nouvelle':'teal','perdue':'rose'};
const presenceOptions: EventStatus[] = ['participation confirmée','avec personne(s) invitée(s)','absence confirmée','en attente','inscription sans présence'];

export default function Home(){
  const [tab,setTab]=useState('dashboard');
  const [members,setMembers]=useState(initialMembers);
  const [attendance,setAttendance]=useState(initialAttendance);
  const currentMonth = new Date().getMonth()+1;
  const past = events.filter(e=>e.status==='passé');
  const presentPast = attendance.filter(a=>past.some(e=>e.id===a.eventId) && ['participation confirmée','avec personne(s) invitée(s)'].includes(a.status)).length;
  const participationRate = Math.round((presentPast/Math.max(past.length*members.length,1))*100);
  const birthdays = useMemo(()=>members.filter(m=>m.birthday && Number(m.birthday.slice(5,7))===currentMonth).sort((a,b)=>a.birthday!.slice(8).localeCompare(b.birthday!.slice(8))),[members,currentMonth]);
  const monthlyLunches = events.filter(e=>e.type==='déjeuner' && new Date(e.date).getMonth()+1===currentMonth).length;
  const wonReco = recommendations.filter(r=>r.status==='gagnée').length;
  const recoRate = Math.round((wonReco/Math.max(recommendations.length,1))*100);
  const sponsored = members.filter(m=>m.sponsorId==='m1').length;
  function setPresence(eventId:string,memberId:string,status:EventStatus){setAttendance(prev=>{const found=prev.some(a=>a.eventId===eventId&&a.memberId===memberId); if(!found)return[...prev,{eventId,memberId,status,guestCount:status==='avec personne(s) invitée(s)'?1:0}]; return prev.map(a=>a.eventId===eventId&&a.memberId===memberId?{...a,status,guestCount:status==='avec personne(s) invitée(s)'?Math.max(a.guestCount||1,1):0}:a)})}
  function presenceFor(eid:string,mid:string){return attendance.find(a=>a.eventId===eid&&a.memberId===mid)?.status||'en attente'}
  function eventStats(eid:string){const list=attendance.filter(a=>a.eventId===eid); return {present:list.filter(a=>['participation confirmée','avec personne(s) invitée(s)'].includes(a.status)).length, guests:list.reduce((s,a)=>s+(a.guestCount||0),0), noShow:list.filter(a=>a.status==='inscription sans présence').length}}
  function importDemo(){setMembers(prev=>[...prev,{id:'m'+Date.now(),firstName:'Nouveau',lastName:'Membre',email:'nouveau@email.fr',birthday:'1991-06-28',city:'Global',job:'À compléter',company:'À compléter',bio:'Fiche importée à compléter.',status:'invité'}])}
  const nav=[['dashboard','🏆 Dashboard admin'],['members','👥 Membres'],['events','📅 Présences'],['reco','🤝 Recommandations'],['news','🗞️ Fil d’actualité'],['profile','⚙️ Ma fiche'],['import','📥 Import & invitations']];
  return <main><section className="hero"><div className="wrap"><span className="badge">✨ Marmite My Business</span><h1>L’app communautaire interactive</h1><p>Membres, anniversaires du mois, repas, présences, personnes invitées, recommandations business, parrainage et fil d’actualité.</p></div></section><div className="wrap layout"><nav className="nav">{nav.map(([id,label])=><button key={id} onClick={()=>setTab(id)} className={tab===id?'active':''}>{label}</button>)}</nav><section className="grid">
  {tab==='dashboard'&&<><div className="grid stats"><Stat label="Membres" value={members.length}/><Stat label="Repas ce mois" value={monthlyLunches}/><Stat label="Participation" value={participationRate+'%'}/><Stat label="Reco gagnées" value={recoRate+'%'}/><Stat label="Personnes parrainées" value={sponsored}/><Stat label="Événements à venir" value={events.filter(e=>e.status==='à venir').length}/></div><div className="grid two"><Card title="🎂 Anniversaires du mois">{birthdays.length?birthdays.map(m=><p key={m.id}><b>{m.firstName} {m.lastName}</b> — {m.birthday!.slice(8)}/{m.birthday!.slice(5,7)}</p>):<p>Aucun anniversaire ce mois-ci.</p>}</Card><Card title="🏅 Top parrainage">{members.map(m=>({m,count:members.filter(x=>x.sponsorId===m.id).length})).sort((a,b)=>b.count-a.count).map(({m,count})=><p key={m.id}><b>{m.firstName}</b> — {count} personne(s) parrainée(s)</p>)}</Card></div><Card title="🤝 Dernières recommandations business"><div className="grid two">{recommendations.map(r=><Reco key={r.id} r={r} members={members}/>)}</div></Card></>}
  {tab==='members'&&<Card title="👥 Annuaire des membres"><div className="grid two">{members.map(m=><div className="member" key={m.id}><h3>{m.firstName} {m.lastName}</h3><p><b>{m.job}</b></p><p className="muted">{m.company} · {m.city}</p><p>{m.bio}</p><span className="pill violet">{members.filter(x=>x.sponsorId===m.id).length} personne(s) parrainée(s)</span></div>)}</div></Card>}
  {tab==='events'&&<div className="grid">{events.map(e=>{const s=eventStats(e.id); const rate=Math.round((s.present/Math.max(members.length,1))*100); return <Card key={e.id} title={'📅 '+e.title}><p className="muted">{e.date} · {e.city} · {e.location}</p><div className="miniStats"><span className="pill green">{s.present} participations confirmées</span><span className="pill teal">+{s.guests} personnes invitées</span><span className="pill slate">{s.noShow} no-show</span><span className="pill violet">{rate}% participation</span></div><div className="rows">{members.map(m=><div className="row" key={m.id}><div><b>{m.firstName} {m.lastName}</b><br/><span className="muted">{m.city} · {m.job}</span></div><select className={statusClass[presenceFor(e.id,m.id)]} value={presenceFor(e.id,m.id)} onChange={ev=>setPresence(e.id,m.id,ev.target.value as EventStatus)}>{presenceOptions.map(o=><option key={o}>{o}</option>)}</select></div>)}</div></Card>})}</div>}
  {tab==='reco'&&<Card title="🤝 Recommandations & opportunités"><p className="muted">Exemple : Arnaud demande à travailler avec Marjorie sur Notion, c’est référencé ici.</p><div className="grid two">{recommendations.map(r=><Reco key={r.id} r={r} members={members}/>)}</div></Card>}
  {tab==='news'&&<Card title="🗞️ Fil d’actualité"><textarea placeholder="Écrire une annonce, une demande, une actualité..."/><br/><button className="btn">Publier</button><div className="rows" style={{marginTop:16}}>{posts.map(p=><div className="post" key={p.id}><b>{p.author} · {p.city}</b><p>{p.content}</p><span className="muted">❤️ 4 · 💬 2</span></div>)}</div></Card>}
  {tab==='profile'&&<Card title="⚙️ Modifier ma fiche"><Profile member={members[0]}/></Card>}
  {tab==='import'&&<Card title="📥 Import & invitations"><p>En production : import CSV/base de données → statut “invité” → email avec lien magique → le membre complète sa fiche en autonomie.</p><button className="btn" onClick={importDemo}>Simuler un import membre</button><div className="notice" style={{marginTop:16}}>À brancher ensuite sur Supabase pour stocker les données et envoyer les invitations automatiquement.</div></Card>}
</section></div></main>}
function Card({title,children}:{title:string;children:React.ReactNode}){return <div className="card"><h2>{title}</h2>{children}</div>}
function Stat({label,value}:{label:string;value:string|number}){return <div className="card stat"><strong>{value}</strong><span>{label}</span></div>}
function Reco({r,members}:{r:Recommendation;members:Member[]}){const from=members.find(m=>m.id===r.fromMemberId); const to=members.find(m=>m.id===r.toMemberId); return <div className="reco"><h3>{r.contactName}</h3><span className={'pill '+statusClass[r.status]}>{r.status}</span><p>{r.need}</p><p className="muted">Recommandé par {from?.firstName} → pour {to?.firstName}</p>{r.value&&<b>Potentiel : {r.value} €</b>}</div>}
function Profile({member}:{member:Member}){const [form,setForm]=useState(member); const [saved,setSaved]=useState(false); const update=(k:keyof Member,v:string)=>{setForm(prev=>({...prev,[k]:v}));setSaved(false)}; return <form onSubmit={e=>{e.preventDefault();setSaved(true)}}><div className="form"><input value={form.firstName} onChange={e=>update('firstName',e.target.value)} placeholder="Prénom"/><input value={form.lastName} onChange={e=>update('lastName',e.target.value)} placeholder="Nom"/><input value={form.email} onChange={e=>update('email',e.target.value)} placeholder="Email"/><input value={form.phone||''} onChange={e=>update('phone',e.target.value)} placeholder="Téléphone"/><input value={form.job} onChange={e=>update('job',e.target.value)} placeholder="Métier"/><input value={form.company} onChange={e=>update('company',e.target.value)} placeholder="Entreprise"/><input type="date" value={form.birthday||''} onChange={e=>update('birthday',e.target.value)}/><select value={form.city} onChange={e=>update('city',e.target.value)}>{['Combourg','Rennes','Saint-Malo','Brest','Global'].map(v=><option key={v}>{v}</option>)}</select><textarea className="full" value={form.bio} onChange={e=>update('bio',e.target.value)} placeholder="Bio"/></div><br/><button className="btn">Enregistrer ma fiche</button>{saved&&<p className="pill green">Fiche enregistrée côté interface test.</p>}</form>}
